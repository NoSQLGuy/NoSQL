/*-
 * Copyright (C) 2011, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This software is licensed with the Universal Permissive License (UPL) version 1.0
 *
 * Please see LICENSE.txt file included in the top-level directory of the
 * appropriate download for a copy of the license and additional information.
 */

package oracle.nosql.cloudsim.examples;

import java.net.URL;
import java.util.List;

import oracle.nosql.driver.NoSQLHandle;
import oracle.nosql.driver.NoSQLHandleConfig;
import oracle.nosql.driver.NoSQLHandleFactory;
import oracle.nosql.driver.NoSQLException;
import oracle.nosql.driver.ops.DeleteRequest;
import oracle.nosql.driver.ops.DeleteResult;
import oracle.nosql.driver.ops.GetRequest;
import oracle.nosql.driver.ops.GetResult;
import oracle.nosql.driver.ops.QueryRequest;
import oracle.nosql.driver.ops.QueryResult;
import oracle.nosql.driver.ops.PutRequest;
import oracle.nosql.driver.ops.PutResult;
import oracle.nosql.driver.ops.TableLimits;
import oracle.nosql.driver.ops.TableRequest;
import oracle.nosql.driver.ops.TableResult;
import oracle.nosql.driver.values.MapValue;

/**
 * A simple program to:
 * 1. connect to a running proxy
 * 2. create a table
 * 3. put a row
 * 4. get a row
 * 5. query a table
 * 6. delete a row
 *
 * Assumptions:
 *
 * There is a running CloudSim instance listening on port 8080 on the
 * local host. If non-default host or port are desired, use flags to
 * change them.
 */
public class BasicTableExample {
    private static final String createTableStatement =
        "create table if not exists users(id integer, " +
        "name string, primary key(id))";

    private static final String PORT_FLAG = "-httpPort";
    private static final String HOST_FLAG = "-host";

    /* change to false to quiet output */
    private static final boolean verbose = true;

    private static void usage() {
        System.err.println(
            "Usage: BasicTableExample [-httpPort <port>] [-host <hostname>]");
        System.exit(1);
    }

    @SuppressWarnings("unused")
    public static void main(String[] args) throws Exception {

        /*
         * Defaults
         */
        final String tenantId = "mytenantId";
        String hostname = "localhost";
        int port = 8080;

        if (args.length > 0) {
            if (args.length != 2 && args.length != 4) {
                usage();
            }
            for (int i = 0; i < args.length; i += 2) {
                if (PORT_FLAG.equals(args[i])) {
                    port = Integer.parseInt(args[i+1]);
                } else if (HOST_FLAG.equals(args[i])) {
                    hostname = args[i+1];
                } else {
                    usage();
                }
            }
        }

        output("Using host " + hostname + ", port " + port);

        /*
         * Configure the endpoint and set the tenant id
         */
        URL serviceURL =
            new URL("http", hostname, port, "/");
        NoSQLHandleConfig config = new NoSQLHandleConfig(serviceURL);
        config.setAuthorizationProvider(
            new ExampleAccessTokenProvider(tenantId));

        /*
         * Open the handle
         */
        NoSQLHandle handle = NoSQLHandleFactory.createNoSQLHandle(config);

        try {

            /*
             * Create a simple table with an integer key and a single
             * name field
             */
            TableRequest tableRequest = new TableRequest()
                .setStatement(createTableStatement)
                .setTableLimits(new TableLimits(500, 500, 500));
            TableResult tres = handle.tableRequest(tableRequest);

            /*
             * Wait for the table to become active. Table request is
             * asynchronous. It's necessary to wait for an expected state
             * to know when the operation has completed.
             */
            tres = TableResult.waitForState(handle,
                                            tres.getTableName(),
                                            TableResult.State.ACTIVE,
                                            30000, /* wait 30 sec */
                                            1000); /* delay ms for poll */

            output("BasicTableExample: created table, statement:\n\t" +
                   createTableStatement);

            /*
             * PUT a row
             */

            /* construct a simple row */
            MapValue value = new MapValue().put("id", 1).put("name", "myname");

            PutRequest putRequest = new PutRequest()
                .setValue(value)
                .setTableName("users");

            PutResult putRes = handle.put(putRequest);
            output("BasicTableExample: put row: " + value);

            /*
             * GET the row
             */
            MapValue key = new MapValue().put("id", 1);
            GetRequest getRequest = new GetRequest()
                .setKey(key)
                .setTableName("users");

            GetResult getRes = handle.get(getRequest);

            output("BasicTableExample: got row: " + getRes.getValue());

            /*
             * PUT a row using JSON
             */

            /* construct a simple row */
            final String jsonString = "{\"id\": 2, \"name\":\"newname\"}";

            putRequest = new PutRequest()
                .setValueFromJson(jsonString, null) // no options
                .setTableName("users");

            putRes = handle.put(putRequest);
            output("BasicTableExample: put row from json: " + jsonString);

            /*
             * GET the new row
             */
            key = new MapValue().put("id", 2);
            getRequest = new GetRequest()
                .setKey(key)
                .setTableName("users");

            getRes = handle.get(getRequest);

            output("BasicTableExample: got new row: " + getRes.getValue());

            /*
             * QUERY the table. The table name is inferred from the
             * query statement.
             */
            QueryRequest queryRequest = new QueryRequest().
                setStatement("select * from users where name = \"myname\"");
            QueryResult qres = handle.query(queryRequest);
            List<MapValue> results = qres.getResults();
            output("BasicTableExample: number of query results: " +
                   results.size());
            for (MapValue qval : qres.getResults()) {
                output("\t" + qval.toString());
            }

            /*
             * DELETE a row
             */
            DeleteRequest delRequest = new DeleteRequest()
                .setKey(key)
                .setTableName("users");

            DeleteResult del = handle.delete(delRequest);
        } catch (NoSQLException nse) {
            System.err.println("Op failed: " + nse.getMessage());
        } catch (Exception e) {
            System.err.println("Exception processing msg: " + e);
            e.printStackTrace();
        } finally {
            /*
             * Shutdown client or process won't exit
             */
            output("BasicTableExample: closing handle");
            handle.close();
        }
    }

    private static void output(String msg) {
        if (verbose) {
            System.out.println(msg);
        }
    }
}
