/*-
 * Copyright (C) 2011, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This software is licensed with the Universal Permissive License (UPL) version 1.0
 *
 * Please see LICENSE.txt file included in the top-level directory of the
 * appropriate download for a copy of the license and additional information.
 */

package oracle.nosql.cloudsim.examples;

import java.net.URL;
import java.util.List;

import oracle.nosql.driver.NoSQLException;
import oracle.nosql.driver.NoSQLHandle;
import oracle.nosql.driver.NoSQLHandleConfig;
import oracle.nosql.driver.NoSQLHandleFactory;
import oracle.nosql.driver.ops.PutRequest;
import oracle.nosql.driver.ops.PutResult;
import oracle.nosql.driver.ops.QueryRequest;
import oracle.nosql.driver.ops.QueryResult;
import oracle.nosql.driver.ops.TableLimits;
import oracle.nosql.driver.ops.TableRequest;
import oracle.nosql.driver.ops.TableResult;
import oracle.nosql.driver.values.MapValue;

/**
 * A simple program to:
 * 1. connect to a running proxy
 * 2. create a table
 * 3. put a row
 * 4. Index Create
 * 5. read from Index
 *
 * Assumptions:
 *
 * There is a running CloudSim instance listening on port 8080 on the local
 * host. If non-default host or port are desired, use flags to change them.
 * Table "usersInfo" created for this example does not exist.
 */
public class IndexExample {
    private static final String createTableStatement =
        "create table if not exists usersInfo(id integer, "
        + "userInfo JSON, primary key(id))";

    private static final String PORT_FLAG = "-httpPort";
    private static final String HOST_FLAG = "-host";

    /* change to false to quiet output */
    private static final boolean verbose = true;

    private static void usage() {
        System.err.println(
            "Usage: Index Operation Example: "
            + "[-httpPort <port>] "
            + "[-host <hostname>]");
        System.exit(1);
    }

    @SuppressWarnings("unused")
    public static void main(String[] args) throws Exception {

        /*
         * Defaults
         */
        final String tenantId = "mytenantId";
        String hostname = "localhost";
        int port = 8080;

        if (args.length > 0) {
            if (args.length != 2 && args.length != 4) {
                usage();
            }
            for (int i = 0; i < args.length; i += 2) {
                if (PORT_FLAG.equals(args[i])) {
                    port = Integer.parseInt(args[i + 1]);
                } else if (HOST_FLAG.equals(args[i])) {
                    hostname = args[i + 1];
                } else {
                    usage();
                }
            }
        }

        output("Using host " + hostname + ", port " + port);

        /*
         * Configure the endpoint and set the tenant id
         */
        URL serviceURL = new URL("http", hostname, port, "/");
        NoSQLHandleConfig config = new NoSQLHandleConfig(serviceURL);
        config.setAuthorizationProvider(
            new ExampleAccessTokenProvider(tenantId));

        /*
         * Open the handle
         */
        NoSQLHandle handle =
            NoSQLHandleFactory.createNoSQLHandle(config);

        try {

            /*
             * Create a simple table with
             * an integer key and a single name field
             */
            TableRequest tableRequest = new TableRequest()
                .setStatement(createTableStatement)
                .setTableLimits(
                    new TableLimits(500, 500, 500));
            TableResult tres = handle.tableRequest(tableRequest);

            /*
             * Wait for the table to become active. Table request
             * is asynchronous. It's necessary to wait for an
             * expected state to know when the operation has
             * completed.
             */
            tres = TableResult.waitForState(
                handle,
                tres.getTableName(),
                TableResult.State.ACTIVE, 30000, /* wait 30 sec */
                1000); /* delay ms for poll */

            output("Index Create example: created table, "
                   + "statement:\n\t"
                   + createTableStatement);

            final String index1 = "CREATE INDEX idx1 on usersInfo"
                + "(userInfo.firstName as string)";

            TableRequest indexTableRequest = new TableRequest()
                .setStatement(index1)
                .setTableLimits(
                    new TableLimits(500, 500, 500));
            TableResult indexTableResult =
                handle.tableRequest(tableRequest);
            /*
             * PUT a row
             */

            /* construct a simple row */
            MapValue value = new MapValue().put("id", 1).
                putFromJson("userInfo",
                            "{\"firstName\":\"myname\","
                            + "\"lastName\":\"mylastName\","
                            + "\"age\":33}",null);

            PutRequest putRequest =
                new PutRequest().setValue(value)
                .setTableName("usersInfo");

            PutResult putRes = handle.put(putRequest);
            output("Index Create example: put row: " + value);

            /* construct a simple row */
            value = new MapValue().put("id", 2).
                putFromJson("userInfo",
                            "{\"firstName\":\"newname\","
                            + "\"lastName\":\"mynewName\","
                            + "\"age\":35}",null);

            // no options
            putRequest = new PutRequest().setValue(value)
                .setTableName("usersInfo");

            putRes = handle.put(putRequest);
            output("Index Create example: put row: " + value);

            /* construct a row */
            value = new MapValue().put("id", 3).
                putFromJson("userInfo",
                            "{\"firstName\":\"friendsname\","
                            + "\"lastName\":\"friendslastName\","
                            + "\"age\":30}",null);

            // no options
            putRequest = new PutRequest().setValue(value)
                .setTableName("usersInfo");

            putRes = handle.put(putRequest);
            output("Index Create example: put row: " + value);

            /* construct a row */
            value = new MapValue().put("id", 4).
                putFromJson("userInfo",
                            "{\"firstName\":\"relativesname\","
                            + "\"lastName\":\"relativeslastName\","
                            + "\"age\":43}",null);

            // no options
            putRequest = new PutRequest().setValue(value)
                .setTableName("usersInfo");

            putRes = handle.put(putRequest);
            output("Index Create example: put row: " + value);

            /*
             * Query from an index
             */
            QueryRequest queryRequest =
                new QueryRequest().setStatement(
                    "select * from usersInfo u where "
                    + "u.userInfo.firstName=\"myname\"");
            output("Query :"+queryRequest.getStatement());
            QueryResult qres = handle.query(queryRequest);
            List<MapValue> results = qres.getResults();
            output("Index Query Example: number of query results: "
                   + results.size());
            for (MapValue qval : qres.getResults()) {
                output("\t" + qval.toString());
            }
        } catch (NoSQLException nse) {
            System.err.println("Op failed: " + nse.getMessage());
        } catch (Exception e) {
            System.err.println("Exception processing msg: " + e);
            e.printStackTrace();
        } finally {
            /*
             * Shutdown client or process won't exit
             */
            output("Index Create example: closing handle");
            handle.close();
        }
    }

    private static void output(String msg) {
        if (verbose) {
            System.out.println(msg);
        }
    }
}
