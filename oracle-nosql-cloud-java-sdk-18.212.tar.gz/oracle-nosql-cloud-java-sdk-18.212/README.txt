A README file for the Oracle Autonomous NoSQL Database Java SDK.
This document describes:
1) how to start an Oracle NoSQL Cloud Simulator instance
2) how to build and run bundled example programs

Troubleshooting information is at the end of this file.

Usage Guidelines

- These instructions assume that the current directory is the root directory
of the archive (the directory that contains this file).

- Oracle NoSQL Cloud Simulator is a utility that enables developers to execute applications developed with the APIs that will be delivered with the Oracle Autonomous NoSQL Database Cloud (ANS). This utility gives developers the ability to test applications without actually connecting to ANS.

- To properly develop the application, the appropriate client driver is needed.  With the initial release of ANS, a Java client driver will be available with other language drivers planned for the future.

- Oracle NoSQL Cloud Simulator cannot be used to store any production data.

- Oracle NoSQL Cloud Simulator runs on your local computer and has been tested on the following operating systems:
    1) Windows 7 and above
    2) Oracle Linux
    3) Mac OS

- The examples are for convenience to help provide an overview of using the API.

- Support for Oracle NoSQL Cloud Simulator and the examples are provided over the forum. Questions should be posted at https://community.oracle.com/community/database/nosql_database or and email to: oraclenosql-info_ww@oracle.com with Oracle NoSQL Cloud Simulator in the subject line.

- Small shell scripts are provided as a convenience to run Oracle NoSQL Cloud Simulator and to build and run example programs that use the Oracle NoSQL Cloud Java SDK. These scripts specify an included logging configuration file. By default, there is no logging.

- Edit the file, logging.properties, to enable the level of logging desired.

Requirements:
 - It is highly recommended to have Java 10 installed and in your PATH.
 - At least 5GB of free disk on the volume containing the root directory


1. start Oracle NoSQL Cloud Simulator
 The only required option is "-root". This defines the directory to hold the store. If this directory does not exist, it will be created. If there is an existing store there, it will be used.

 $ ./runCloudSim -root <path-to-a-rootdir>

 This call creates an instance of Oracle NoSQL Cloud Simulator and starts a cloud proxy in the same process using the default ports for the store and HTTP proxy. The proxy listens for cloud driver requests on an HTTP port.

 There are additional options that can be used to control the cloud sim instance.

 Options and default values:
     -host - localhost
     -storePort - 5000
     -httpPort - 8080
     -throttle - false. If set to true throttling exceptions will be thrown if throughput is exceeded

   To see a usage message:
   $ ./runCloudSim -?

   Oracle NoSQL Cloud Simulator can be put in the background using:
   $ ./runCloudSim -root <path-to-a-rootdir> &

   The Oracle NoSQL Cloud Simulator instance can be stopped using ^C or otherwise killing the process.

2. To build and run Java examples

 To build all examples
 $ examples/java/buildExamples

 To run an example
 $ examples/java/runExample <example> [-host <hostname>] [-httpPort <port>]
 e.g.
 $ examples/java/runExample BasicTableExample

 Note that the runExample script will use the local logging.properties file for logging configuration. By default logging is off and can be enabled by modifying the levels for oracle.nosql and/or io.netty.

 There are 4 examples included with this download in the examples/java directory.

 a. BasicTableExample.java - Program that shows how to Create a table insert and retrieve using GET and Query records and delete table.
 b. DeleteExample.java - Program that shows how to delete a single row and delete multiple rows in a table.
 c. IndexExample.java - Program that shows how to create an index on a column in the table and retrieve from an index.
 d. ExampleAccessTokenProvider.java - Program that shows use of tenant id.

3. To run the examples against the ANS service please refer to the Authentication and Authorization FAQ.

4. Javadoc for applications is included with this archive and is in the java/javadoc
directory.

Troubleshooting

1. Failure to start the Oracle NoSQL Cloud Simulator server.
  a) failed to start KVLite. This might occur if there is a process using the default port 5000. In this case use a different port using -storePort <port>

  b) failed to start the proxy. This might occur if there is a process using the default port of 8080. In this case use the -httpPort <port> flag to use a non-default port. This also means specifying -httpPort <port> when calling the example classes which have a hard-coded default of 8080.

2. Example class fails to contact proxy. This probably means that the Oracle NoSQL Cloud Simulator server isn't running, or is running using a different HTTP port. These need to match.

3. To run Oracle NoSQL Cloud Simulator or the example program with logging, edit logging.properties to set the desired level of logging and re-run the scripts.

4. If you have questions regarding the API for Oracle NoSQL Cloud Simulator, please send an email to oraclenosql-info_ww@oracle.com with Oracle NoSQL Cloud Simulator in the subject line, and someone will get back to you as soon as possible.
